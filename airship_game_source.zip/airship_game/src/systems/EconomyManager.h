#pragma once
#include "../Constants.h"
#include <unordered_map>

class EconomyManager {
public:
    int redCredits  = 300;
    int blueCredits = 300;

    int getCredits(Team t) const {
        return t == Team::Red ? redCredits : blueCredits;
    }

    void addCredits(Team t, int amount) {
        if (t == Team::Red)  redCredits  += amount;
        if (t == Team::Blue) blueCredits += amount;
    }

    bool spend(Team t, int amount) {
        if (t == Team::Red && redCredits >= amount) {
            redCredits -= amount; return true;
        }
        if (t == Team::Blue && blueCredits >= amount) {
            blueCredits -= amount; return true;
        }
        return false;
    }

    // Passive income tick
    void tick(float dt) {
        static float timer = 0.f;
        timer += dt;
        if (timer >= 5.f) {
            timer = 0.f;
            redCredits  += 10;
            blueCredits += 10;
        }
    }
};

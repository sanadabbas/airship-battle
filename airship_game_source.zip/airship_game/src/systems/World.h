#pragma once
#include "../Constants.h"
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>

struct ExplorationZone {
    ZoneType     type;
    sf::Vector2f position;
    float        radius;
    std::string  name;
    bool         discovered = false;
    int          creditBonus = 0;
    sf::Color    color;
    sf::Color    glowColor;
    float        glowTimer = 0.f;
    bool         hasDamageHazard = false; // asteroid fields
};

struct Star {
    sf::Vector2f position;
    float        size;
    float        brightness;
    sf::Color    color;
    float        twinkle = 0.f;
    float        twinkleSpeed = 1.f;
};

class World {
public:
    std::vector<ExplorationZone> zones;
    std::vector<Star>            stars;
    std::vector<Star>            bgStars; // parallax background

    World() {
        generateStars();
        generateZones();
    }

    void update(float dt) {
        for (auto& z : zones) {
            z.glowTimer += dt;
        }
    }

    void draw(sf::RenderTarget& target, const sf::View& gameView) {
        // Draw zones
        for (auto& z : zones) {
            float pulse = 0.5f + 0.5f * std::sin(z.glowTimer * 1.2f);

            // Outer glow
            sf::CircleShape glow(z.radius * 1.5f);
            glow.setFillColor(sf::Color(z.glowColor.r, z.glowColor.g, z.glowColor.b, (int)(30 + 20*pulse)));
            glow.setOrigin(z.radius*1.5f, z.radius*1.5f);
            glow.setPosition(z.position);
            target.draw(glow);

            // Body
            sf::CircleShape body(z.radius, getSides(z.type));
            sf::Color col = z.color;
            if (z.discovered) col.a = 255;
            else              col.a = 160;
            body.setFillColor(col);
            body.setOutlineColor(sf::Color(z.glowColor.r, z.glowColor.g, z.glowColor.b, 200));
            body.setOutlineThickness(2.f);
            body.setOrigin(z.radius, z.radius);
            body.setPosition(z.position);
            body.setRotation(z.glowTimer * 8.f);
            target.draw(body);

            // Stars get a bright core
            if (z.type == ZoneType::Star) {
                sf::CircleShape core(z.radius * 0.4f);
                core.setFillColor(sf::Color(255,240,200,(int)(180+40*pulse)));
                core.setOrigin(z.radius*0.4f, z.radius*0.4f);
                core.setPosition(z.position);
                target.draw(core);
            }

            // Discovery label
            if (z.discovered) {
                // rendered in HUD not here (needs font)
            }
        }

        // Draw world stars (small sparkles)
        for (auto& s : stars) {
            float tw = 0.5f + 0.5f * std::sin(s.twinkle);
            sf::CircleShape dot(s.size * tw);
            dot.setFillColor(sf::Color(s.color.r, s.color.g, s.color.b, (int)(s.brightness * 255 * tw)));
            dot.setOrigin(s.size * tw, s.size * tw);
            dot.setPosition(s.position);
            target.draw(dot);
        }
    }

    void updateStarTwinkle(float dt) {
        for (auto& s : stars) {
            s.twinkle += dt * s.twinkleSpeed;
        }
    }

    // Returns zone if player is inside it
    ExplorationZone* getZoneAt(sf::Vector2f pos) {
        for (auto& z : zones) {
            float dx = z.position.x - pos.x;
            float dy = z.position.y - pos.y;
            if (std::sqrt(dx*dx+dy*dy) < z.radius) return &z;
        }
        return nullptr;
    }

private:
    int getSides(ZoneType t) {
        switch(t) {
            case ZoneType::Star:          return 16;
            case ZoneType::Planet:        return 12;
            case ZoneType::AsteroidField: return 7;
            case ZoneType::Nebula:        return 20;
            case ZoneType::Cache:         return 5;
        }
        return 8;
    }

    void generateStars() {
        stars.reserve(600);
        for (int i = 0; i < 600; i++) {
            Star s;
            s.position = {(float)(rand() % (int)WORLD_W), (float)(rand() % (int)WORLD_H)};
            s.size     = 0.5f + (rand() % 20) * 0.1f;
            s.brightness = 0.3f + (rand()%70)*0.01f;
            int r = rand() % 3;
            if (r == 0) s.color = sf::Color(200, 210, 255);
            else if (r==1) s.color = sf::Color(255,240,200);
            else s.color = sf::Color(220,220,220);
            s.twinkleSpeed = 0.3f + (rand()%30)*0.05f;
            s.twinkle = (float)(rand()%100)*0.1f;
            stars.push_back(s);
        }
    }

    void generateZones() {
        // Star clusters (6)
        const char* starNames[] = {"Alpha Centauri","Betelgeuse","Rigel","Vega","Arcturus","Sirius"};
        for (int i = 0; i < 6; i++) {
            ExplorationZone z;
            z.type   = ZoneType::Star;
            z.radius = 80.f + rand()%60;
            z.position = safePos(z.radius);
            z.name   = starNames[i];
            z.creditBonus = 30 + rand()%40;
            z.color  = sf::Color(255, 200+rand()%55, 60+rand()%80);
            z.glowColor = sf::Color(255, 180, 60);
            zones.push_back(z);
        }
        // Planets (8)
        const char* planetNames[] = {"Kethara","Vorn","Solax","Dreya","Nimbus","Caldor","Ixion","Pyreth"};
        sf::Color planetColors[] = {
            {80,180,240},{160,100,200},{200,160,80},{80,200,120},
            {200,80,120},{140,200,160},{100,140,220},{220,140,80}
        };
        for (int i = 0; i < 8; i++) {
            ExplorationZone z;
            z.type   = ZoneType::Planet;
            z.radius = 60.f + rand()%50;
            z.position = safePos(z.radius);
            z.name   = planetNames[i];
            z.creditBonus = 20 + rand()%30;
            z.color  = planetColors[i];
            z.glowColor = sf::Color(z.color.r/2, z.color.g/2, z.color.b);
            zones.push_back(z);
        }
        // Asteroid fields (5)
        for (int i = 0; i < 5; i++) {
            ExplorationZone z;
            z.type   = ZoneType::AsteroidField;
            z.radius = 120.f + rand()%80;
            z.position = safePos(z.radius);
            z.name   = "Asteroid Belt " + std::to_string(i+1);
            z.creditBonus = 0;
            z.hasDamageHazard = true;
            z.color  = sf::Color(140,120,100,180);
            z.glowColor = sf::Color(160,140,100);
            zones.push_back(z);
        }
        // Nebulae (4)
        const char* nebulaNames[] = {"Crimson Veil","Azure Drift","Emerald Cloud","Phantom Mist"};
        sf::Color nebColors[] = {{200,60,80,120},{60,100,200,120},{60,180,100,120},{160,60,200,120}};
        for (int i = 0; i < 4; i++) {
            ExplorationZone z;
            z.type   = ZoneType::Nebula;
            z.radius = 150.f + rand()%100;
            z.position = safePos(z.radius);
            z.name   = nebulaNames[i];
            z.creditBonus = 15;
            z.color  = nebColors[i];
            z.glowColor = sf::Color(nebColors[i].r, nebColors[i].g, nebColors[i].b);
            zones.push_back(z);
        }
        // Resource caches (6)
        for (int i = 0; i < 6; i++) {
            ExplorationZone z;
            z.type   = ZoneType::Cache;
            z.radius = 35.f;
            z.position = safePos(z.radius);
            z.name   = "Cache-" + std::to_string(i+1);
            z.creditBonus = 60 + rand()%80;
            z.color  = sf::Color(220,200,60);
            z.glowColor = sf::Color(255,220,80);
            zones.push_back(z);
        }
    }

    sf::Vector2f safePos(float r) {
        // Avoid team base corners
        while(true) {
            float x = r + rand()%(int)(WORLD_W - 2*r);
            float y = r + rand()%(int)(WORLD_H - 2*r);
            // Keep away from edges where bases are
            if (x > 300 && x < WORLD_W-300 && y > 300 && y < WORLD_H-300)
                return {x, y};
        }
    }
};

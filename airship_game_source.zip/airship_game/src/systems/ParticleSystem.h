#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <cmath>

struct Particle {
    sf::Vector2f pos;
    sf::Vector2f vel;
    sf::Color    color;
    float        life;
    float        maxLife;
    float        size;
    float        rotation;
    float        rotSpeed;
};

class ParticleSystem {
public:
    std::vector<Particle> particles;

    void spawnExplosion(sf::Vector2f pos, sf::Color col, int count = 30, float speed = 120.f) {
        for (int i = 0; i < count; i++) {
            float angle = (rand()%360) * 3.14159f/180.f;
            float spd   = speed * (0.3f + (rand()%100)*0.007f);
            Particle p;
            p.pos  = pos;
            p.vel  = {std::cos(angle)*spd, std::sin(angle)*spd};
            p.color= col;
            p.life = p.maxLife = 0.6f + (rand()%60)*0.01f;
            p.size = 3.f + (rand()%8)*0.5f;
            p.rotation = (float)(rand()%360);
            p.rotSpeed = (rand()%200 - 100) * 0.5f;
            particles.push_back(p);
        }
        // Shockwave flash
        Particle flash;
        flash.pos = pos;
        flash.vel = {0,0};
        flash.color = sf::Color(255,240,200,200);
        flash.life = flash.maxLife = 0.15f;
        flash.size = 2.f;
        flash.rotation = 0; flash.rotSpeed = 0;
        particles.push_back(flash);
    }

    void spawnDebris(sf::Vector2f pos, sf::Color col, int count = 15) {
        for (int i = 0; i < count; i++) {
            float angle = (rand()%360) * 3.14159f/180.f;
            float spd = 60.f + rand()%80;
            Particle p;
            p.pos  = pos;
            p.vel  = {std::cos(angle)*spd, std::sin(angle)*spd};
            p.color= col;
            p.life = p.maxLife = 1.2f + (rand()%80)*0.01f;
            p.size = 2.f + (rand()%6);
            p.rotation = (float)(rand()%360);
            p.rotSpeed = (rand()%300 - 150) * 0.5f;
            particles.push_back(p);
        }
    }

    void spawnHit(sf::Vector2f pos, sf::Color col) {
        for (int i = 0; i < 8; i++) {
            float angle = (rand()%360) * 3.14159f/180.f;
            float spd = 80.f + rand()%60;
            Particle p;
            p.pos = pos; p.vel = {std::cos(angle)*spd, std::sin(angle)*spd};
            p.color = col; p.life = p.maxLife = 0.25f;
            p.size = 2.f; p.rotation=0; p.rotSpeed=0;
            particles.push_back(p);
        }
    }

    void update(float dt) {
        for (auto& p : particles) {
            p.pos += p.vel * dt;
            p.vel *= std::pow(0.6f, dt);
            p.life -= dt;
            p.rotation += p.rotSpeed * dt;
            float f = p.life / p.maxLife;
            p.color.a = (sf::Uint8)(f * 255);
            p.size    *= (0.98f);
        }
        particles.erase(
            std::remove_if(particles.begin(), particles.end(),
                [](const Particle& p){ return p.life <= 0.f || p.size < 0.3f; }),
            particles.end()
        );
    }

    void draw(sf::RenderTarget& target) {
        for (const auto& p : particles) {
            sf::RectangleShape s({p.size, p.size});
            s.setFillColor(p.color);
            s.setOrigin(p.size/2.f, p.size/2.f);
            s.setPosition(p.pos);
            s.setRotation(p.rotation);
            target.draw(s);
        }
    }
};

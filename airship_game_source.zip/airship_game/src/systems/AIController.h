#pragma once
#include "../entities/Ship.h"
#include "../entities/Structure.h"
#include <vector>
#include <cmath>
#include <algorithm>

class AIController {
public:
    void update(Ship& ship, float dt,
                std::vector<std::unique_ptr<Ship>>& allShips,
                std::vector<std::unique_ptr<Structure>>& structures,
                std::function<void(Projectile)> shootCallback)
    {
        if (!ship.alive || ship.isPlayer) return;

        // Find nearest enemy ship
        Ship*      nearestEnemy = nullptr;
        Structure* nearestStructure = nullptr;
        float      bestDist = 1e9f;

        for (auto& s : allShips) {
            if (!s->alive || s->team == ship.team) continue;
            float d = dist(ship.position, s->position);
            if (d < bestDist) { bestDist = d; nearestEnemy = s.get(); }
        }

        // Find nearest enemy structure
        float bestStructDist = 1e9f;
        for (auto& st : structures) {
            if (st->destroyed || st->team == ship.team) continue;
            float d = dist(ship.position, st->position);
            if (d < bestStructDist) { bestStructDist = d; nearestStructure = st.get(); }
        }

        // State transitions
        float hpRatio = ship.hpFraction();
        if (hpRatio < AI_RETREAT_HP) {
            ship.aiState = Ship::AIState::Retreat;
        } else if (nearestEnemy && bestDist < AI_CHASE_RANGE) {
            ship.aiState = Ship::AIState::Chase;
            ship.aiTarget = nearestEnemy;
        } else if (nearestEnemy && bestDist < AI_ATTACK_RANGE) {
            ship.aiState = Ship::AIState::Attack;
            ship.aiTarget = nearestEnemy;
        } else {
            ship.aiState = Ship::AIState::Patrol;
        }

        // Execute state
        switch(ship.aiState) {
            case Ship::AIState::Patrol:
                doPatrol(ship, dt, structures);
                break;
            case Ship::AIState::Chase:
                if (ship.aiTarget) doChase(ship, dt, *ship.aiTarget);
                break;
            case Ship::AIState::Attack:
                if (ship.aiTarget) doAttack(ship, dt, *ship.aiTarget, shootCallback);
                break;
            case Ship::AIState::Retreat:
                doRetreat(ship, dt, structures);
                break;
            default:
                doPatrol(ship, dt, structures);
                break;
        }

        // Also shoot at enemy structures if in range
        if (ship.aiState != Ship::AIState::Retreat && nearestStructure) {
            float d = dist(ship.position, nearestStructure->position);
            if (d < ship.stats.weaponRange * 1.1f && ship.canFire()) {
                // Aim at structure
                aimAt(ship, nearestStructure->position, dt);
                float angleDiff = angleTo(ship, nearestStructure->position);
                if (std::abs(angleDiff) < 20.f) {
                    shootCallback(ship.fire());
                }
            }
        }
    }

private:
    float dist(sf::Vector2f a, sf::Vector2f b) {
        float dx = a.x-b.x, dy = a.y-b.y;
        return std::sqrt(dx*dx+dy*dy);
    }

    float angleTo(const Ship& ship, sf::Vector2f target) {
        sf::Vector2f d = target - ship.position;
        float targetAngle = std::atan2(d.x, -d.y) * 180.f / 3.14159f;
        float diff = targetAngle - ship.rotation;
        while (diff >  180) diff -= 360;
        while (diff < -180) diff += 360;
        return diff;
    }

    void aimAt(Ship& ship, sf::Vector2f target, float dt) {
        float diff = angleTo(ship, target);
        ship.turnInput = (diff > 0) ? 1.f : -1.f;
        if (std::abs(diff) < 5.f) ship.turnInput = diff / 5.f;
    }

    void doPatrol(Ship& ship, float dt, std::vector<std::unique_ptr<Structure>>& structures) {
        // Patrol toward enemy side
        float targetX = (ship.team == Team::Red) ? WORLD_W * 0.6f + (rand()%1000) : WORLD_W * 0.4f - (rand()%1000);
        float targetY = WORLD_H * 0.3f + rand()%((int)(WORLD_H * 0.4f));

        if (dist(ship.position, ship.patrolTarget) < 100.f || ship.patrolTarget == sf::Vector2f{}) {
            ship.patrolTarget = {targetX, targetY};
        }

        aimAt(ship, ship.patrolTarget, dt);
        float diff = std::abs(angleTo(ship, ship.patrolTarget));
        ship.engineThrust = (diff < 60.f) ? 1.f : 0.3f;
    }

    void doChase(Ship& ship, float dt, Entity& target) {
        aimAt(ship, target.position, dt);
        ship.engineThrust = 1.f;
    }

    void doAttack(Ship& ship, float dt, Entity& target, std::function<void(Projectile)> shoot) {
        aimAt(ship, target.position, dt);
        float d = dist(ship.position, target.position);
        // Maintain range
        if (d > ship.stats.weaponRange * 0.85f) ship.engineThrust = 0.8f;
        else if (d < ship.stats.weaponRange * 0.4f) ship.engineThrust = -0.5f;
        else ship.engineThrust = 0.f;

        float diff = angleTo(ship, target.position);
        if (std::abs(diff) < 15.f && ship.canFire()) {
            shoot(ship.fire());
        }
    }

    void doRetreat(Ship& ship, float dt, std::vector<std::unique_ptr<Structure>>& structures) {
        // Retreat toward own base
        sf::Vector2f home = (ship.team == Team::Red) ? sf::Vector2f{200.f, WORLD_H/2.f} : sf::Vector2f{WORLD_W-200.f, WORLD_H/2.f};
        aimAt(ship, home, dt);
        ship.engineThrust = 1.f;
        // Recover hp slowly when retreating
        ship.hp = std::min(ship.maxHp, ship.hp + 10.f * dt);
    }
};

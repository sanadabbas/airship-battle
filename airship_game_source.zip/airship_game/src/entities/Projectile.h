#pragma once
#include "../Constants.h"
#include <SFML/Graphics.hpp>

struct Projectile {
    sf::Vector2f position;
    sf::Vector2f velocity;
    float        damage   = 20.f;
    float        lifetime = BULLET_LIFETIME;
    Team         owner    = Team::None;
    bool         alive    = true;
    float        radius   = 4.f;
    sf::Color    color    = sf::Color::Yellow;

    void update(float dt) {
        position += velocity * dt;
        lifetime -= dt;
        if (lifetime <= 0.f) alive = false;
    }

    void draw(sf::RenderTarget& target) const {
        sf::CircleShape s(radius);
        s.setFillColor(color);
        s.setOrigin(radius, radius);
        s.setPosition(position);
        target.draw(s);

        // glow trail
        sf::CircleShape glow(radius * 2.2f);
        glow.setFillColor(sf::Color(color.r, color.g, color.b, 60));
        glow.setOrigin(radius*2.2f, radius*2.2f);
        glow.setPosition(position);
        target.draw(glow);
    }
};

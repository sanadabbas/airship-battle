#pragma once
#include "Entity.h"
#include "Projectile.h"
#include <cmath>
#include <string>

class Structure : public Entity {
public:
    StructureType structType;
    float radius  = 40.f;
    float fireCooldown = 0.f;
    float fireRate     = 0.4f; // shots/sec
    float weaponRange  = 300.f;
    float weaponDamage = 18.f;
    bool  destroyed    = false;
    int   repairCost   = 100;
    float maxHpBase    = 300.f;

    // Upgrade level (0-3)
    int   upgradeLevel = 0;

    std::function<void(Projectile)> onShoot;

    Structure(StructureType t, Team tm, sf::Vector2f pos) : structType(t) {
        team     = tm;
        position = pos;
        destroyed = false;
        alive = true;
        setupStats();
    }

    void setupStats() {
        switch(structType) {
            case StructureType::OuterTurret:
                maxHp = 200.f; repairCost = 80;  fireRate = 0.5f; weaponDamage = 15.f; weaponRange = 320.f; radius = 30.f; break;
            case StructureType::InnerTurret:
                maxHp = 300.f; repairCost = 120; fireRate = 0.7f; weaponDamage = 22.f; weaponRange = 350.f; radius = 34.f; break;
            case StructureType::ShieldStation:
                maxHp = 350.f; repairCost = 150; fireRate = 0.f;  weaponDamage = 0.f;  weaponRange = 0.f;   radius = 36.f;
                maxShield = 200.f; shield = 200.f; shieldRegen = 15.f; break;
            case StructureType::RepairBay:
                maxHp = 250.f; repairCost = 100; fireRate = 0.f;  weaponDamage = 0.f;  weaponRange = 0.f;   radius = 38.f; break;
            case StructureType::Nexus:
                maxHp = 1000.f; repairCost = 300; fireRate = 0.8f; weaponDamage = 30.f; weaponRange = 400.f; radius = 55.f;
                maxShield = 400.f; shield = 400.f; shieldRegen = 20.f; break;
        }
        maxHpBase = maxHp;
        hp = maxHp;
    }

    void upgrade() {
        if (upgradeLevel >= 3) return;
        upgradeLevel++;
        weaponDamage *= 1.3f;
        fireRate     *= 1.2f;
        weaponRange  *= 1.1f;
        maxHp         = maxHpBase * (1.f + 0.25f * upgradeLevel);
        hp = std::min(hp + maxHpBase * 0.25f, maxHp);
    }

    void repair(float amount) {
        hp = std::min(maxHp, hp + amount);
        if (hp > 0.f) { alive = true; destroyed = false; }
    }

    void update(float dt) override {
        if (destroyed) return;
        Entity::update(dt);
        if (fireCooldown > 0.f) fireCooldown -= dt;
    }

    bool canFireAt(sf::Vector2f target) const {
        if (destroyed || fireRate <= 0.f || fireCooldown > 0.f) return false;
        float dx = target.x - position.x;
        float dy = target.y - position.y;
        return std::sqrt(dx*dx + dy*dy) <= weaponRange;
    }

    Projectile fireAt(sf::Vector2f target) {
        fireCooldown = 1.f / fireRate;
        sf::Vector2f dir = target - position;
        float len = std::sqrt(dir.x*dir.x + dir.y*dir.y);
        if (len > 0) dir /= len;

        Projectile p;
        p.position = position;
        p.velocity = dir * BULLET_SPEED;
        p.damage   = weaponDamage;
        p.owner    = team;
        p.color    = (team == Team::Red) ? sf::Color(255,80,80) : sf::Color(80,180,255);
        p.radius   = (structType == StructureType::Nexus) ? 7.f : 5.f;
        return p;
    }

    void takeDamage(float dmg) {
        Entity::takeDamage(dmg);
        if (hp <= 0.f) destroyed = true;
    }

    std::string getName() const {
        switch(structType) {
            case StructureType::OuterTurret:  return "Outer Turret";
            case StructureType::InnerTurret:  return "Inner Turret";
            case StructureType::ShieldStation:return "Shield Station";
            case StructureType::RepairBay:    return "Repair Bay";
            case StructureType::Nexus:        return "NEXUS";
        }
        return "Structure";
    }

    void draw(sf::RenderTarget& target) override {
        if (destroyed) {
            // Draw rubble
            sf::CircleShape rubble(radius * 0.6f, 6);
            rubble.setFillColor(sf::Color(80,60,50,120));
            rubble.setOutlineColor(sf::Color(100,80,60,180));
            rubble.setOutlineThickness(2.f);
            rubble.setOrigin(radius*0.6f, radius*0.6f);
            rubble.setPosition(position);
            target.draw(rubble);
            return;
        }

        sf::Color baseCol;
        int sides;
        switch(structType) {
            case StructureType::OuterTurret:   baseCol = sf::Color(160,160,160); sides = 4; break;
            case StructureType::InnerTurret:   baseCol = sf::Color(190,190,100); sides = 4; break;
            case StructureType::ShieldStation: baseCol = sf::Color(80,120,200);  sides = 6; break;
            case StructureType::RepairBay:     baseCol = sf::Color(60,180,120);  sides = 5; break;
            case StructureType::Nexus:         baseCol = sf::Color(220,180,40);  sides = 8; break;
        }

        // Body
        sf::CircleShape body(radius, sides);
        body.setFillColor(baseCol);
        body.setOutlineColor(teamColor(team));
        body.setOutlineThickness(3.f);
        body.setOrigin(radius, radius);
        body.setPosition(position);
        body.setRotation(structType == StructureType::Nexus ? (float)(rand()%3) : 45.f);
        target.draw(body);

        // Turret barrel
        if (structType == StructureType::OuterTurret || structType == StructureType::InnerTurret || structType == StructureType::Nexus) {
            sf::RectangleShape barrel({6.f, radius});
            barrel.setFillColor(sf::Color(80,80,80));
            barrel.setOrigin(3.f, radius);
            barrel.setPosition(position);
            barrel.setRotation(rotation);
            target.draw(barrel);
        }

        // Upgrade indicator dots
        for (int i = 0; i < upgradeLevel; i++) {
            sf::CircleShape dot(4.f);
            dot.setFillColor(sf::Color(255,220,40));
            dot.setOrigin(4.f, 4.f);
            dot.setPosition(position.x - 10.f + i*10.f, position.y + radius + 6.f);
            target.draw(dot);
        }

        // HP bar
        float barW = radius * 2.2f;
        sf::RectangleShape hpBg({barW, 6.f});
        hpBg.setFillColor(sf::Color(60,20,20));
        hpBg.setPosition(position.x - barW/2.f, position.y - radius - 14.f);
        target.draw(hpBg);

        float frac = hpFraction();
        sf::RectangleShape hpBar({barW * frac, 6.f});
        hpBar.setFillColor(frac > 0.5f ? sf::Color(80,220,80) : frac > 0.25f ? sf::Color(220,180,40) : sf::Color(220,60,60));
        hpBar.setPosition(position.x - barW/2.f, position.y - radius - 14.f);
        target.draw(hpBar);

        if (maxShield > 0.f) {
            float alpha = (shield/maxShield) * 80.f;
            sf::CircleShape sc(radius * 1.35f, 12);
            sc.setFillColor(sf::Color(80,140,255,(int)alpha));
            sc.setOutlineColor(sf::Color(120,180,255,(int)(alpha*1.8f)));
            sc.setOutlineThickness(1.5f);
            sc.setOrigin(radius*1.35f, radius*1.35f);
            sc.setPosition(position);
            target.draw(sc);
        }
    }
};

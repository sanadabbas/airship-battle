#pragma once
#include "Entity.h"
#include "Projectile.h"
#include <vector>
#include <functional>
#include <cmath>

struct ShipStats {
    float maxHp;
    float maxShield;
    float shieldRegen;
    float speed;
    float turnSpeed;     // deg/sec
    float weaponDamage;
    float fireRate;      // shots/sec
    float weaponRange;
    float collisionRadius;
    int   killCredits;
    sf::Color color;
    float size;
};

inline ShipStats defaultStats(ShipType t) {
    switch(t) {
        case ShipType::Scout:
            return {80,30,12,280,180,15,2.5f,350,14,CREDIT_SCOUT_KILL,sf::Color(200,240,200),14.f};
        case ShipType::Gunship:
            return {150,60,8,180,120,25,1.8f,400,18,CREDIT_GUNSHIP_KILL,sf::Color(200,200,100),18.f};
        case ShipType::Dreadnought:
            return {400,150,5,80,60,45,0.8f,320,28,CREDIT_DREADNOUGHT_KILL,sf::Color(200,140,80),28.f};
        case ShipType::Carrier:
            return {250,100,10,120,80,18,1.2f,380,24,CREDIT_CARRIER_KILL,sf::Color(180,140,220),24.f};
        case ShipType::Miner:
            return {120,20,6,150,100,12,1.0f,300,16,CREDIT_MINER_KILL,sf::Color(160,200,240),16.f};
    }
    return {100,0,5,150,120,20,1.5f,350,16,50,sf::Color::White,16.f};
}

class Ship : public Entity {
public:
    ShipType  type;
    ShipStats stats;
    bool      isPlayer   = false;

    // Upgrades (multipliers)
    float damageMulti    = 1.f;
    float fireRateMulti  = 1.f;
    float shieldCapMulti = 1.f;
    float shieldRegenMulti = 1.f;
    float speedMulti     = 1.f;
    float armorMulti     = 1.f;  // damage reduction

    float fireCooldown   = 0.f;
    float engineThrust   = 0.f;  // -1 to 1
    float turnInput      = 0.f;  // -1 to 1

    // Drone count for Carrier
    int   droneCount     = 0;
    float droneSpawnTimer = 0.f;

    // Mining
    bool  isMining       = false;
    float mineTimer      = 0.f;

    // AI state
    enum class AIState { Patrol, Chase, Attack, Retreat, Escort };
    AIState aiState = AIState::Patrol;
    sf::Vector2f patrolTarget;
    Entity* aiTarget = nullptr;

    std::function<void(Projectile)> onShoot;

    Ship(ShipType t, Team tm) : type(t) {
        stats     = defaultStats(t);
        team      = tm;
        maxHp     = stats.maxHp;
        hp        = stats.maxHp;
        maxShield = stats.maxShield;
        shield    = stats.maxShield;
        shieldRegen = stats.shieldRegen;
    }

    void update(float dt) override {
        // Shield regen
        shieldRegen = stats.shieldRegen * shieldRegenMulti;
        Entity::update(dt);

        float spd = stats.speed * speedMulti;
        float rot = stats.turnSpeed;

        // Apply rotation
        rotation += turnInput * rot * dt;

        // Thrust
        float rad = rotation * 3.14159f / 180.f;
        sf::Vector2f fwd(std::sin(rad), -std::cos(rad));
        velocity += fwd * engineThrust * spd * dt * 4.f;

        // Drag
        velocity *= std::pow(0.15f, dt);

        // Clamp to world
        position.x = std::max(20.f, std::min(WORLD_W - 20.f, position.x));
        position.y = std::max(20.f, std::min(WORLD_H - 20.f, position.y));

        // Fire cooldown
        if (fireCooldown > 0.f) fireCooldown -= dt;

        // Carrier drone spawn
        if (type == ShipType::Carrier) {
            droneSpawnTimer -= dt;
            if (droneSpawnTimer <= 0.f && droneCount < 4) {
                droneSpawnTimer = 8.f;
                droneCount++;
            }
        }

        // Miner income
        if (isMining) {
            mineTimer += dt;
        }
    }

    bool canFire() const {
        return fireCooldown <= 0.f;
    }

    Projectile fire() {
        float rate = stats.fireRate * fireRateMulti;
        fireCooldown = 1.f / rate;

        float rad = rotation * 3.14159f / 180.f;
        sf::Vector2f fwd(std::sin(rad), -std::cos(rad));
        sf::Vector2f tip = position + fwd * (stats.collisionRadius + 8.f);

        Projectile p;
        p.position = tip;
        p.velocity = fwd * BULLET_SPEED + velocity * 0.3f;
        p.damage   = stats.weaponDamage * damageMulti;
        p.owner    = team;
        p.color    = (team == Team::Red) ? sf::Color(255,100,80) : sf::Color(100,180,255);
        p.radius   = (type == ShipType::Dreadnought) ? 6.f : 4.f;
        return p;
    }

    void draw(sf::RenderTarget& target) override {
        float sz = stats.size;
        sf::Color col = stats.color;

        // Ship body — triangle pointing up (rotated)
        sf::ConvexShape body;
        body.setPointCount(5);
        body.setPoint(0, {0, -sz});           // nose
        body.setPoint(1, {sz*0.55f, sz*0.5f});
        body.setPoint(2, {sz*0.25f, sz*0.25f});
        body.setPoint(3, {-sz*0.25f, sz*0.25f});
        body.setPoint(4, {-sz*0.55f, sz*0.5f});
        body.setFillColor(col);
        body.setOutlineColor(teamColor(team));
        body.setOutlineThickness(2.f);
        body.setOrigin(0, 0);
        body.setPosition(position);
        body.setRotation(rotation);
        target.draw(body);

        // Engine glow when thrusting
        if (std::abs(engineThrust) > 0.1f) {
            sf::ConvexShape flame;
            flame.setPointCount(3);
            float fs = sz * 0.4f * std::abs(engineThrust);
            flame.setPoint(0, {0, sz*0.35f});
            flame.setPoint(1, {-sz*0.2f, sz*0.35f + fs*2.f});
            flame.setPoint(2, {sz*0.2f, sz*0.35f + fs*2.f});
            flame.setFillColor(sf::Color(255, 160+rand()%60, 40, 180));
            flame.setPosition(position);
            flame.setRotation(rotation);
            target.draw(flame);
        }

        // Shield bubble
        if (shield > 0.f && maxShield > 0.f) {
            float alpha = (shield/maxShield) * 80.f;
            sf::CircleShape shieldCircle(sz * 1.4f);
            shieldCircle.setFillColor(sf::Color(80, 140, 255, (int)alpha));
            shieldCircle.setOutlineColor(sf::Color(120, 180, 255, (int)(alpha * 1.5f)));
            shieldCircle.setOutlineThickness(1.5f);
            shieldCircle.setOrigin(sz*1.4f, sz*1.4f);
            shieldCircle.setPosition(position);
            target.draw(shieldCircle);
        }

        // HP bar
        float barW = sz * 2.f;
        sf::RectangleShape hpBg({barW, 4.f});
        hpBg.setFillColor(sf::Color(60, 20, 20));
        hpBg.setPosition(position.x - barW/2.f, position.y - sz - 12.f);
        target.draw(hpBg);

        sf::RectangleShape hpBar({barW * hpFraction(), 4.f});
        sf::Color hpCol = hpFraction() > 0.5f ? sf::Color(80,220,80) :
                          hpFraction() > 0.25f ? sf::Color(220,180,40) : sf::Color(220,60,60);
        hpBar.setFillColor(hpCol);
        hpBar.setPosition(position.x - barW/2.f, position.y - sz - 12.f);
        target.draw(hpBar);

        // Shield bar
        if (maxShield > 0.f) {
            sf::RectangleShape sBg({barW, 3.f});
            sBg.setFillColor(sf::Color(20,20,60));
            sBg.setPosition(position.x - barW/2.f, position.y - sz - 7.f);
            target.draw(sBg);
            sf::RectangleShape sBar({barW * shieldFraction(), 3.f});
            sBar.setFillColor(sf::Color(80,140,255));
            sBar.setPosition(position.x - barW/2.f, position.y - sz - 7.f);
            target.draw(sBar);
        }
    }

    float getRadius() const { return stats.collisionRadius; }

    void applyUpgrade(UpgradeType u) {
        switch(u) {
            case UpgradeType::WeaponDamage:   damageMulti   *= 1.25f; break;
            case UpgradeType::WeaponFireRate:  fireRateMulti *= 1.20f; break;
            case UpgradeType::ShieldCapacity:
                shieldCapMulti *= 1.30f;
                maxShield = stats.maxShield * shieldCapMulti;
                shield = maxShield;
                break;
            case UpgradeType::ShieldRegen:     shieldRegenMulti *= 1.40f; break;
            case UpgradeType::Speed:           speedMulti   *= 1.20f; break;
            case UpgradeType::HullArmor:       armorMulti   *= 0.80f; break; // 20% damage reduction
        }
    }

    void takeDamage(float dmg) {
        Entity::takeDamage(dmg * armorMulti);
    }
};

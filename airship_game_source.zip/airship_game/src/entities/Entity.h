#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.h"

class Entity {
public:
    sf::Vector2f position;
    sf::Vector2f velocity;
    float rotation = 0.f;
    bool alive = true;
    Team team = Team::None;

    float maxHp = 100.f;
    float hp    = 100.f;
    float maxShield = 0.f;
    float shield    = 0.f;
    float shieldRegen = 5.f; // per second

    virtual ~Entity() = default;
    virtual void update(float dt) {
        position += velocity * dt;
        if (shield < maxShield) shield = std::min(maxShield, shield + shieldRegen * dt);
    }
    virtual void draw(sf::RenderTarget& target) = 0;

    float hpFraction()     const { return hp / maxHp; }
    float shieldFraction() const { return maxShield > 0 ? shield / maxShield : 0.f; }
    bool  isDead()         const { return !alive || hp <= 0.f; }

    void takeDamage(float dmg) {
        if (shield > 0.f) {
            float absorbed = std::min(shield, dmg);
            shield -= absorbed;
            dmg    -= absorbed;
        }
        hp -= dmg;
        if (hp <= 0.f) { hp = 0.f; alive = false; }
    }

    sf::FloatRect bounds(float r = 20.f) const {
        return {position.x - r, position.y - r, r*2.f, r*2.f};
    }
};

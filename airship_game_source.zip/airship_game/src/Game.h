#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>
#include <functional>
#include <string>

#include "Constants.h"
#include "entities/Ship.h"
#include "entities/Structure.h"
#include "entities/Projectile.h"
#include "systems/EconomyManager.h"
#include "systems/World.h"
#include "systems/ParticleSystem.h"
#include "systems/AIController.h"
#include "ui/HUD.h"

class Game {
public:
    Game();
    void run();

private:
    sf::RenderWindow window;
    sf::View         gameView;
    GameState        state = GameState::Menu;

    // Game objects
    std::vector<std::unique_ptr<Ship>>      ships;
    std::vector<std::unique_ptr<Structure>> structures;
    std::vector<Projectile>                 projectiles;

    Ship*            player = nullptr;

    EconomyManager   economy;
    World            world;
    ParticleSystem   particles;
    AIController     ai;
    HUD              hud;

    float gameTime = 0.f;
    int   fps      = 0;
    float fpsTimer = 0.f;
    int   fpsCount = 0;

    sf::Font    menuFont;
    bool        menuFontLoaded = false;

    // Ship selection in menu
    int         selectedShipType = 0;

    void handleEvents();
    void handlePlayerInput(float dt);
    void updateGame(float dt);
    void updateCollisions();
    void updateAI(float dt);
    void checkVictory();
    void render();
    void renderMenu();
    void renderGame();
    void renderPause();
    void renderVictory(bool win);

    void setupBases();
    void spawnAIWave();
    float aiSpawnTimer = 0.f;

    void addProjectile(Projectile p) { projectiles.push_back(p); }

    // Upgrade menu
    void handleUpgradeInput(sf::Keyboard::Key key);

    // Check if player is near repair bay
    Structure* getNearbyRepairBay();

    // Text helper
    void drawCenteredText(sf::RenderTarget& t, const std::string& str,
                          float y, int size, sf::Color col);
};

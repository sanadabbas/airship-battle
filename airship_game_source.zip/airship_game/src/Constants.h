#pragma once
#include <SFML/Graphics.hpp>
#include <string>

constexpr int WINDOW_W = 1280;
constexpr int WINDOW_H = 720;
constexpr float WORLD_W = 6000.f;
constexpr float WORLD_H = 6000.f;

enum class Team { None, Red, Blue };
inline sf::Color teamColor(Team t) {
    if (t == Team::Red)  return sf::Color(220,80,80);
    if (t == Team::Blue) return sf::Color(80,140,220);
    return sf::Color(180,180,180);
}

enum class ShipType { Scout, Gunship, Dreadnought, Carrier, Miner };
inline std::string shipTypeName(ShipType t) {
    switch(t){
        case ShipType::Scout:       return "Scout";
        case ShipType::Gunship:     return "Gunship";
        case ShipType::Dreadnought: return "Dreadnought";
        case ShipType::Carrier:     return "Carrier";
        case ShipType::Miner:       return "Miner";
    }
    return "Unknown";
}

enum class StructureType { OuterTurret, InnerTurret, ShieldStation, RepairBay, Nexus };
enum class GameState { Menu, Playing, Paused, Victory, Defeat };

enum class UpgradeType { WeaponDamage, WeaponFireRate, ShieldCapacity, ShieldRegen, Speed, HullArmor };
inline std::string upgradeName(UpgradeType u) {
    switch(u){
        case UpgradeType::WeaponDamage:   return "Weapon Damage +25%";
        case UpgradeType::WeaponFireRate: return "Fire Rate +20%";
        case UpgradeType::ShieldCapacity: return "Shield Cap +30%";
        case UpgradeType::ShieldRegen:    return "Shield Regen +40%";
        case UpgradeType::Speed:          return "Engine Speed +20%";
        case UpgradeType::HullArmor:      return "Hull Armor +25%";
    }
    return "";
}
constexpr int UPGRADE_COST = 150;

constexpr int CREDIT_SCOUT_KILL       = 50;
constexpr int CREDIT_GUNSHIP_KILL     = 80;
constexpr int CREDIT_DREADNOUGHT_KILL = 120;
constexpr int CREDIT_CARRIER_KILL     = 100;
constexpr int CREDIT_MINER_KILL       = 60;
constexpr int CREDIT_STRUCTURE_KILL   = 40;

constexpr float BULLET_SPEED    = 500.f;
constexpr float BULLET_LIFETIME = 2.5f;

constexpr float AI_ATTACK_RANGE = 350.f;
constexpr float AI_CHASE_RANGE  = 500.f;
constexpr float AI_RETREAT_HP   = 0.2f;

enum class ZoneType { Star, Planet, AsteroidField, Nebula, Cache };

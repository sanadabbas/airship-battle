#pragma once
#include <SFML/Graphics.hpp>
#include "../entities/Ship.h"
#include "../entities/Structure.h"
#include "../systems/EconomyManager.h"
#include "../systems/World.h"
#include <sstream>
#include <iomanip>

class HUD {
    sf::Font font;
    bool fontLoaded = false;

    // Notification
    std::string notification;
    float       notifTimer = 0.f;

public:
    bool showUpgradeMenu = false;
    int  upgradeMenuSelection = 0;
    bool atRepairBay = false;

    HUD() {
        // Try several system font paths
        const char* paths[] = {
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
            "/usr/share/fonts/truetype/ubuntu/Ubuntu-B.ttf",
        };
        for (auto p : paths) {
            if (font.loadFromFile(p)) { fontLoaded = true; break; }
        }
    }

    void showNotification(const std::string& msg) {
        notification = msg;
        notifTimer   = 3.f;
    }

    void update(float dt) {
        if (notifTimer > 0.f) notifTimer -= dt;
    }

    void draw(sf::RenderTarget& target, const Ship* player,
              const EconomyManager& economy, int fps,
              const std::vector<std::unique_ptr<Structure>>& structures,
              ExplorationZone* currentZone, float gameTime)
    {
        if (!fontLoaded) return;

        sf::View hudView(sf::FloatRect(0, 0, WINDOW_W, WINDOW_H));
        target.setView(hudView);

        // ── Top bar background ──
        sf::RectangleShape topBar({(float)WINDOW_W, 52.f});
        topBar.setFillColor(sf::Color(10,10,18,200));
        target.draw(topBar);

        // Credits
        drawText(target, "CREDITS: " + std::to_string(economy.getCredits(Team::Red)),
                 14, 8, 14, sf::Color(220,180,60));
        drawText(target, "BLUE: " + std::to_string(economy.getCredits(Team::Blue)),
                 WINDOW_W - 160, 8, 14, sf::Color(100,180,255));

        // FPS
        drawText(target, "FPS:" + std::to_string(fps), WINDOW_W - 80, 36, 11, sf::Color(120,120,120));

        // Game time
        int min = (int)gameTime / 60, sec = (int)gameTime % 60;
        std::ostringstream ts;
        ts << std::setfill('0') << std::setw(2) << min << ":" << std::setw(2) << sec;
        drawText(target, ts.str(), WINDOW_W/2 - 20, 16, 18, sf::Color(200,200,200));

        if (!player) return;

        // ── Player HP/Shield bars (bottom left) ──
        float barX = 14, barY = WINDOW_H - 90;
        float barW = 220, barH = 18;

        // HP
        sf::RectangleShape hpBg({barW, barH});
        hpBg.setFillColor(sf::Color(40,15,15,220));
        hpBg.setPosition(barX, barY);
        target.draw(hpBg);
        float hpFrac = player->hpFraction();
        sf::RectangleShape hpBar({barW*hpFrac, barH});
        hpBar.setFillColor(hpFrac>0.5f?sf::Color(60,200,60):hpFrac>0.25f?sf::Color(220,160,40):sf::Color(220,60,60));
        hpBar.setPosition(barX, barY);
        target.draw(hpBar);
        drawText(target, "HP " + std::to_string((int)player->hp) + "/" + std::to_string((int)player->maxHp),
                 barX+4, barY+2, 12, sf::Color(220,220,220));

        // Shield
        if (player->maxShield > 0.f) {
            sf::RectangleShape sBg({barW, 12.f});
            sBg.setFillColor(sf::Color(10,20,50,220));
            sBg.setPosition(barX, barY + barH + 4);
            target.draw(sBg);
            sf::RectangleShape sBar({barW*player->shieldFraction(), 12.f});
            sBar.setFillColor(sf::Color(60,130,240));
            sBar.setPosition(barX, barY + barH + 4);
            target.draw(sBar);
            drawText(target, "SHIELD", barX+4, barY+barH+5, 10, sf::Color(140,180,255));
        }

        // Ship name
        drawText(target, shipTypeName(player->type), barX, barY - 22, 14, teamColor(player->team));

        // Upgrade multipliers
        std::ostringstream upg;
        upg << "DMG x" << std::fixed << std::setprecision(1) << player->damageMulti
            << "  SPD x" << player->speedMulti;
        drawText(target, upg.str(), barX, barY - 40, 11, sf::Color(180,180,100));

        // ── Minimap ──
        drawMinimap(target, *player, structures);

        // ── Zone info ──
        if (currentZone) {
            sf::RectangleShape zoneBg({260.f, 52.f});
            zoneBg.setFillColor(sf::Color(10,10,20,180));
            zoneBg.setPosition(WINDOW_W/2.f - 130.f, WINDOW_H - 60.f);
            target.draw(zoneBg);
            drawText(target, currentZone->name,
                     WINDOW_W/2 - 120, WINDOW_H - 52, 14,
                     currentZone->discovered ? sf::Color(220,200,60) : sf::Color(180,180,180));
            if (!currentZone->discovered) {
                drawText(target, "UNDISCOVERED - +" + std::to_string(currentZone->creditBonus) + " credits",
                         WINDOW_W/2 - 120, WINDOW_H - 34, 11, sf::Color(140,220,140));
            } else {
                std::string typeStr;
                switch(currentZone->type) {
                    case ZoneType::Star: typeStr="Star System"; break;
                    case ZoneType::Planet: typeStr="Planet"; break;
                    case ZoneType::AsteroidField: typeStr="Asteroid Field - HAZARD"; break;
                    case ZoneType::Nebula: typeStr="Nebula"; break;
                    case ZoneType::Cache: typeStr="Resource Cache"; break;
                }
                drawText(target, typeStr, WINDOW_W/2 - 120, WINDOW_H - 34, 11, sf::Color(160,180,200));
            }
        }

        // ── Repair bay prompt ──
        if (atRepairBay && !showUpgradeMenu) {
            sf::RectangleShape prompt({320.f, 32.f});
            prompt.setFillColor(sf::Color(20,40,20,220));
            prompt.setPosition(WINDOW_W/2.f - 160.f, WINDOW_H - 110.f);
            target.draw(prompt);
            drawText(target, "Press U to open Upgrade Menu", WINDOW_W/2 - 140, WINDOW_H - 104, 14, sf::Color(120,255,120));
        }

        // ── Upgrade menu ──
        if (showUpgradeMenu) {
            drawUpgradeMenu(target, economy.getCredits(player->team));
        }

        // ── Notification ──
        if (notifTimer > 0.f) {
            float alpha = std::min(1.f, notifTimer) * 255.f;
            sf::RectangleShape notifBg({(float)(notification.size()*9+20), 36.f});
            notifBg.setFillColor(sf::Color(20,20,20,(int)(alpha*0.8f)));
            notifBg.setPosition(WINDOW_W/2.f - notifBg.getSize().x/2.f, 60.f);
            target.draw(notifBg);
            drawText(target, notification,
                     WINDOW_W/2 - (int)notification.size()*4,
                     66, 16, sf::Color(255,220,80,(int)alpha));
        }

        // ── Controls hint ──
        drawText(target, "WASD/Arrows:Move  Space:Fire  U:Upgrade  ESC:Pause",
                 14, WINDOW_H - 18, 11, sf::Color(100,100,100));
    }

    void drawUpgradeMenu(sf::RenderTarget& target, int credits) {
        float panelW = 400.f, panelH = 360.f;
        float px = WINDOW_W/2.f - panelW/2.f, py = WINDOW_H/2.f - panelH/2.f;

        sf::RectangleShape panel({panelW, panelH});
        panel.setFillColor(sf::Color(12,16,28,240));
        panel.setOutlineColor(sf::Color(80,140,220));
        panel.setOutlineThickness(2.f);
        panel.setPosition(px, py);
        target.draw(panel);

        drawText(target, "UPGRADE HANGAR", px+20, py+12, 18, sf::Color(220,180,60));
        drawText(target, "Credits: " + std::to_string(credits), px+20, py+38, 14, sf::Color(180,200,80));
        drawText(target, "Cost: " + std::to_string(UPGRADE_COST) + " each", px+200, py+38, 13, sf::Color(160,160,160));

        const UpgradeType upgrades[] = {
            UpgradeType::WeaponDamage, UpgradeType::WeaponFireRate,
            UpgradeType::ShieldCapacity, UpgradeType::ShieldRegen,
            UpgradeType::Speed, UpgradeType::HullArmor
        };

        for (int i = 0; i < 6; i++) {
            float iy = py + 75.f + i * 44.f;
            bool selected = (i == upgradeMenuSelection);
            bool canAfford = (credits >= UPGRADE_COST);

            sf::RectangleShape row({panelW - 40.f, 38.f});
            row.setFillColor(selected ? sf::Color(30,50,80,220) : sf::Color(18,22,36,180));
            row.setOutlineColor(selected ? sf::Color(100,180,255) : sf::Color(40,50,70));
            row.setOutlineThickness(selected ? 2.f : 1.f);
            row.setPosition(px+20, iy);
            target.draw(row);

            sf::Color textCol = canAfford ? sf::Color(200,220,255) : sf::Color(120,120,120);
            if (selected) textCol = sf::Color(255,240,160);
            drawText(target, std::to_string(i+1) + ". " + upgradeName(upgrades[i]),
                     px+30, iy+10, 14, textCol);
        }

        drawText(target, "1-6: Select  Enter/Space: Buy  ESC: Close",
                 px+20, py+panelH-28, 11, sf::Color(120,140,160));
    }

    void drawMinimap(sf::RenderTarget& target, const Ship& player,
                     const std::vector<std::unique_ptr<Structure>>& structures)
    {
        float mapX = WINDOW_W - 170.f, mapY = 60.f;
        float mapW = 155.f, mapH = 155.f;
        float scaleX = mapW / WORLD_W, scaleY = mapH / WORLD_H;

        sf::RectangleShape bg({mapW, mapH});
        bg.setFillColor(sf::Color(8,10,20,210));
        bg.setOutlineColor(sf::Color(60,80,120));
        bg.setOutlineThickness(1.5f);
        bg.setPosition(mapX, mapY);
        target.draw(bg);

        // Structures
        for (auto& s : structures) {
            if (s->destroyed) continue;
            float mx = mapX + s->position.x * scaleX;
            float my = mapY + s->position.y * scaleY;
            sf::CircleShape dot(3.f);
            dot.setFillColor(teamColor(s->team));
            dot.setOrigin(3.f,3.f);
            dot.setPosition(mx, my);
            target.draw(dot);
        }

        // Player (bright dot)
        float px2 = mapX + player.position.x * scaleX;
        float py2 = mapY + player.position.y * scaleY;
        sf::CircleShape pdot(4.f);
        pdot.setFillColor(sf::Color(255,255,255));
        pdot.setOrigin(4.f,4.f);
        pdot.setPosition(px2, py2);
        target.draw(pdot);

        drawText(target, "MAP", mapX+2, mapY+2, 10, sf::Color(80,100,140));
    }

    void drawText(sf::RenderTarget& target, const std::string& str,
                  float x, float y, int size, sf::Color color)
    {
        if (!fontLoaded) return;
        sf::Text t;
        t.setFont(font);
        t.setString(str);
        t.setCharacterSize(size);
        t.setFillColor(color);
        t.setPosition(x, y);
        target.draw(t);
    }
};

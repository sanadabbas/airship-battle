#include "Game.h"
#include <cstdlib>
#include <ctime>

int main() {
    std::srand((unsigned)std::time(nullptr));
    Game game;
    game.run();
    return 0;
}

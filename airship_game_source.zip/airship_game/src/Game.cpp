#include "Game.h"
#include <cmath>
#include <algorithm>
#include <sstream>

Game::Game()
    : window(sf::VideoMode(WINDOW_W, WINDOW_H), "Airship Battle",
             sf::Style::Titlebar | sf::Style::Close)
    , gameView(sf::FloatRect(0, 0, WINDOW_W, WINDOW_H))
{
    window.setFramerateLimit(60);

    const char* fontPaths[] = {
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-B.ttf",
        nullptr
    };
    for (int i = 0; fontPaths[i]; i++) {
        if (menuFont.loadFromFile(fontPaths[i])) { menuFontLoaded = true; break; }
    }
}

void Game::run() {
    sf::Clock clock;
    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();
        dt = std::min(dt, 0.05f); // cap

        // FPS
        fpsCount++;
        fpsTimer += dt;
        if (fpsTimer >= 1.f) {
            fps = fpsCount;
            fpsCount = 0;
            fpsTimer = 0.f;
        }

        handleEvents();

        if (state == GameState::Playing) {
            gameTime += dt;
            handlePlayerInput(dt);
            updateGame(dt);
            hud.update(dt);
        }

        render();
    }
}

void Game::handleEvents() {
    sf::Event ev;
    while (window.pollEvent(ev)) {
        if (ev.type == sf::Event::Closed) window.close();

        if (ev.type == sf::Event::KeyPressed) {
            if (state == GameState::Menu) {
                if (ev.key.code == sf::Keyboard::Return ||
                    ev.key.code == sf::Keyboard::Space) {
                    // Start game with selected ship
                    ships.clear(); structures.clear(); projectiles.clear();
                    particles = ParticleSystem();
                    gameTime  = 0.f;
                    economy.redCredits = 300;
                    economy.blueCredits = 300;
                    aiSpawnTimer = 15.f;

                    setupBases();

                    // Spawn player
                    ShipType types[] = {ShipType::Scout, ShipType::Gunship,
                                        ShipType::Dreadnought, ShipType::Carrier, ShipType::Miner};
                    auto ps = std::make_unique<Ship>(types[selectedShipType], Team::Red);
                    ps->isPlayer = true;
                    ps->position = {200.f, WORLD_H / 2.f};
                    player = ps.get();
                    ships.push_back(std::move(ps));

                    // Spawn initial AI ships for red team (helpers)
                    for (int i = 0; i < 3; i++) {
                        auto ai2 = std::make_unique<Ship>(ShipType::Gunship, Team::Red);
                        ai2->position = {150.f + rand()%200, WORLD_H/2.f - 200.f + rand()%400};
                        ships.push_back(std::move(ai2));
                    }
                    // Blue team initial ships
                    for (int i = 0; i < 4; i++) {
                        ShipType t = (i%2==0) ? ShipType::Gunship : ShipType::Scout;
                        auto ai2 = std::make_unique<Ship>(t, Team::Blue);
                        ai2->position = {WORLD_W-200.f + rand()%200-100.f, WORLD_H/2.f - 200.f + rand()%400};
                        ships.push_back(std::move(ai2));
                    }

                    state = GameState::Playing;
                }
                if (ev.key.code == sf::Keyboard::Left || ev.key.code == sf::Keyboard::A)
                    selectedShipType = (selectedShipType + 4) % 5;
                if (ev.key.code == sf::Keyboard::Right || ev.key.code == sf::Keyboard::D)
                    selectedShipType = (selectedShipType + 1) % 5;
            }
            else if (state == GameState::Playing) {
                if (ev.key.code == sf::Keyboard::Escape) {
                    if (hud.showUpgradeMenu) hud.showUpgradeMenu = false;
                    else state = GameState::Paused;
                }
                if (ev.key.code == sf::Keyboard::U) {
                    if (getNearbyRepairBay()) {
                        hud.showUpgradeMenu = !hud.showUpgradeMenu;
                        hud.upgradeMenuSelection = 0;
                    }
                }
                if (hud.showUpgradeMenu) {
                    handleUpgradeInput(ev.key.code);
                }
            }
            else if (state == GameState::Paused) {
                if (ev.key.code == sf::Keyboard::Escape ||
                    ev.key.code == sf::Keyboard::Return)
                    state = GameState::Playing;
                if (ev.key.code == sf::Keyboard::M) {
                    state = GameState::Menu;
                    ships.clear(); structures.clear(); projectiles.clear();
                    player = nullptr;
                }
            }
            else if (state == GameState::Victory || state == GameState::Defeat) {
                if (ev.key.code == sf::Keyboard::Return ||
                    ev.key.code == sf::Keyboard::Space ||
                    ev.key.code == sf::Keyboard::Escape) {
                    state = GameState::Menu;
                    ships.clear(); structures.clear(); projectiles.clear();
                    player = nullptr;
                }
            }
        }
    }
}

void Game::handlePlayerInput(float dt) {
    if (!player || !player->alive || hud.showUpgradeMenu) return;

    bool up    = sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up);
    bool down  = sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down);
    bool left  = sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left);
    bool right = sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right);

    player->turnInput   = left ? -1.f : right ? 1.f : 0.f;
    player->engineThrust= up   ?  1.f : down  ? -0.6f : 0.f;

    if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Space) ||
         sf::Keyboard::isKeyPressed(sf::Keyboard::LControl)) && player->canFire()) {
        addProjectile(player->fire());
    }
}

void Game::updateGame(float dt) {
    economy.tick(dt);
    world.update(dt);
    world.updateStarTwinkle(dt);

    // Update ships
    for (auto& s : ships) {
        if (!s->alive) continue;
        s->update(dt);

        // Asteroid field damage
        ExplorationZone* zone = world.getZoneAt(s->position);
        if (zone && zone->hasDamageHazard && !zone->discovered) {
            s->takeDamage(5.f * dt);
        }
        // Discovery
        if (zone && !zone->discovered && s->team == Team::Red && s->isPlayer) {
            zone->discovered = true;
            economy.addCredits(Team::Red, zone->creditBonus);
            hud.showNotification("Discovered " + zone->name + " +" + std::to_string(zone->creditBonus) + " credits!");
        }

        // Miner income
        if (s->type == ShipType::Miner) {
            s->mineTimer += dt;
            if (s->mineTimer >= 1.f) {
                s->mineTimer = 0.f;
                economy.addCredits(s->team, 2);
            }
        }
    }

    // Update structures
    for (auto& st : structures) {
        st->update(dt);
        if (st->destroyed) continue;

        // Auto-aim turret rotation toward nearest enemy
        float bestDist = 1e9f;
        sf::Vector2f bestPos = st->position + sf::Vector2f(0, -100);
        for (auto& s : ships) {
            if (!s->alive || s->team == st->team) continue;
            float d = std::hypot(s->position.x-st->position.x, s->position.y-st->position.y);
            if (d < bestDist) { bestDist=d; bestPos=s->position; }
        }
        // Rotate toward target
        sf::Vector2f dir = bestPos - st->position;
        st->rotation = std::atan2(dir.x, -dir.y) * 180.f / 3.14159f;

        // Fire
        for (auto& s : ships) {
            if (!s->alive || s->team == st->team) continue;
            if (st->canFireAt(s->position)) {
                addProjectile(st->fireAt(s->position));
                break;
            }
        }
    }

    // Update projectiles
    for (auto& p : projectiles) p.update(dt);

    // Update particles
    particles.update(dt);

    // Collisions
    updateCollisions();

    // AI
    updateAI(dt);

    // AI spawn waves
    aiSpawnTimer -= dt;
    if (aiSpawnTimer <= 0.f) {
        spawnAIWave();
        aiSpawnTimer = 20.f;
    }

    // Clean dead ships
    for (auto& s : ships) {
        if (s->isDead() && s->alive) {
            s->alive = false;
            particles.spawnExplosion(s->position, teamColor(s->team), 40, 150.f);
            particles.spawnDebris(s->position, s->stats.color, 20);
            // Credits for kill
            Team killer = (s->team == Team::Red) ? Team::Blue : Team::Red;
            int reward = 0;
            switch(s->type) {
                case ShipType::Scout:       reward = CREDIT_SCOUT_KILL; break;
                case ShipType::Gunship:     reward = CREDIT_GUNSHIP_KILL; break;
                case ShipType::Dreadnought: reward = CREDIT_DREADNOUGHT_KILL; break;
                case ShipType::Carrier:     reward = CREDIT_CARRIER_KILL; break;
                case ShipType::Miner:       reward = CREDIT_MINER_KILL; break;
            }
            economy.addCredits(killer, reward);
            if (s->isPlayer) {
                player = nullptr;
                hud.showNotification("YOUR SHIP DESTROYED! Respawning...");
            }
        }
    }

    // Respawn player if dead
    if (!player) {
        static float respawnTimer = 5.f;
        respawnTimer -= dt;
        if (respawnTimer <= 0.f) {
            respawnTimer = 5.f;
            ShipType types[] = {ShipType::Scout, ShipType::Gunship,
                                 ShipType::Dreadnought, ShipType::Carrier, ShipType::Miner};
            auto ps = std::make_unique<Ship>(types[selectedShipType], Team::Red);
            ps->isPlayer = true;
            ps->position = {200.f, WORLD_H/2.f};
            player = ps.get();
            ships.push_back(std::move(ps));
            hud.showNotification("Respawned! Choose an upgrade wisely.");
        }
    }

    // Remove dead ships (keep for 2 sec for particles)
    ships.erase(std::remove_if(ships.begin(), ships.end(),
        [](const std::unique_ptr<Ship>& s){ return !s->alive; }), ships.end());

    // Remove dead projectiles
    projectiles.erase(std::remove_if(projectiles.begin(), projectiles.end(),
        [](const Projectile& p){ return !p.alive; }), projectiles.end());

    // Camera follow player
    if (player) {
        sf::Vector2f target = player->position;
        sf::Vector2f curr   = gameView.getCenter();
        gameView.setCenter(curr + (target - curr) * 5.f * dt);

        // Clamp camera
        float hw = WINDOW_W / 2.f, hh = WINDOW_H / 2.f;
        sf::Vector2f c = gameView.getCenter();
        c.x = std::max(hw, std::min(WORLD_W - hw, c.x));
        c.y = std::max(hh, std::min(WORLD_H - hh, c.y));
        gameView.setCenter(c);
    }

    // Repair bay proximity
    Structure* rb = getNearbyRepairBay();
    hud.atRepairBay = (rb != nullptr);

    checkVictory();
}

void Game::updateCollisions() {
    for (auto& proj : projectiles) {
        if (!proj.alive) continue;

        // vs ships
        for (auto& s : ships) {
            if (!s->alive || s->team == proj.owner) continue;
            float dx = s->position.x - proj.position.x;
            float dy = s->position.y - proj.position.y;
            float dist2 = dx*dx + dy*dy;
            float rSum  = s->getRadius() + proj.radius;
            if (dist2 < rSum*rSum) {
                s->takeDamage(proj.damage);
                particles.spawnHit(proj.position,
                    (proj.owner==Team::Red)?sf::Color(255,100,80):sf::Color(80,160,255));
                proj.alive = false;
                break;
            }
        }
        if (!proj.alive) continue;

        // vs structures
        for (auto& st : structures) {
            if (st->destroyed || st->team == proj.owner) continue;
            float dx = st->position.x - proj.position.x;
            float dy = st->position.y - proj.position.y;
            if (std::sqrt(dx*dx+dy*dy) < st->radius + proj.radius) {
                st->takeDamage(proj.damage);
                particles.spawnHit(proj.position, sf::Color(200,180,100));
                if (st->destroyed) {
                    particles.spawnExplosion(st->position, teamColor(st->team), 50, 120.f);
                    Team winner = (st->team == Team::Red) ? Team::Blue : Team::Red;
                    economy.addCredits(winner, CREDIT_STRUCTURE_KILL);
                    hud.showNotification(st->getName() + " DESTROYED!");
                }
                proj.alive = false;
                break;
            }
        }
    }
}

void Game::updateAI(float dt) {
    for (auto& s : ships) {
        if (!s->alive || s->isPlayer) continue;
        ai.update(*s, dt, ships, structures, [this](Projectile p){ addProjectile(p); });
    }
}

void Game::spawnAIWave() {
    // Red team reinforcements
    int redCount = 0, blueCount = 0;
    for (auto& s : ships) {
        if (s->alive) {
            if (s->team == Team::Red)  redCount++;
            if (s->team == Team::Blue) blueCount++;
        }
    }
    if (redCount < 6) {
        ShipType t = (rand()%3==0) ? ShipType::Dreadnought : ShipType::Gunship;
        auto s = std::make_unique<Ship>(t, Team::Red);
        s->position = {100.f + rand()%150, WORLD_H/2.f - 300.f + rand()%600};
        ships.push_back(std::move(s));
    }
    if (blueCount < 8) {
        ShipType types[] = {ShipType::Scout, ShipType::Gunship, ShipType::Dreadnought};
        auto s = std::make_unique<Ship>(types[rand()%3], Team::Blue);
        s->position = {WORLD_W-100.f - rand()%150, WORLD_H/2.f - 300.f + rand()%600};
        ships.push_back(std::move(s));
        if (rand()%3==0) {
            auto s2 = std::make_unique<Ship>(ShipType::Scout, Team::Blue);
            s2->position = {WORLD_W-120.f, WORLD_H/2.f + rand()%200-100.f};
            ships.push_back(std::move(s2));
        }
    }
}

void Game::setupBases() {
    // Red team base (left side)
    // Nexus
    structures.push_back(std::make_unique<Structure>(StructureType::Nexus, Team::Red, sf::Vector2f{160.f, WORLD_H/2.f}));
    // Repair bay
    structures.push_back(std::make_unique<Structure>(StructureType::RepairBay, Team::Red, sf::Vector2f{220.f, WORLD_H/2.f - 120.f}));
    // Shield stations
    structures.push_back(std::make_unique<Structure>(StructureType::ShieldStation, Team::Red, sf::Vector2f{300.f, WORLD_H/2.f + 160.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::ShieldStation, Team::Red, sf::Vector2f{300.f, WORLD_H/2.f - 160.f}));
    // Inner turrets
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Red, sf::Vector2f{500.f, WORLD_H/2.f - 220.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Red, sf::Vector2f{500.f, WORLD_H/2.f + 220.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Red, sf::Vector2f{500.f, WORLD_H/2.f}));
    // Outer turrets
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Red, sf::Vector2f{900.f, WORLD_H/2.f - 350.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Red, sf::Vector2f{900.f, WORLD_H/2.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Red, sf::Vector2f{900.f, WORLD_H/2.f + 350.f}));

    // Blue team base (right side)
    float bx = WORLD_W;
    structures.push_back(std::make_unique<Structure>(StructureType::Nexus, Team::Blue, sf::Vector2f{bx-160.f, WORLD_H/2.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::RepairBay, Team::Blue, sf::Vector2f{bx-220.f, WORLD_H/2.f - 120.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::ShieldStation, Team::Blue, sf::Vector2f{bx-300.f, WORLD_H/2.f + 160.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::ShieldStation, Team::Blue, sf::Vector2f{bx-300.f, WORLD_H/2.f - 160.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Blue, sf::Vector2f{bx-500.f, WORLD_H/2.f - 220.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Blue, sf::Vector2f{bx-500.f, WORLD_H/2.f + 220.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::InnerTurret, Team::Blue, sf::Vector2f{bx-500.f, WORLD_H/2.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Blue, sf::Vector2f{bx-900.f, WORLD_H/2.f - 350.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Blue, sf::Vector2f{bx-900.f, WORLD_H/2.f}));
    structures.push_back(std::make_unique<Structure>(StructureType::OuterTurret, Team::Blue, sf::Vector2f{bx-900.f, WORLD_H/2.f + 350.f}));
}

void Game::checkVictory() {
    bool redNexusDead = false, blueNexusDead = false;
    for (auto& st : structures) {
        if (st->structType == StructureType::Nexus) {
            if (st->team == Team::Red  && st->destroyed) redNexusDead  = true;
            if (st->team == Team::Blue && st->destroyed) blueNexusDead = true;
        }
    }
    if (blueNexusDead) state = GameState::Victory;
    if (redNexusDead)  state = GameState::Defeat;
}

Structure* Game::getNearbyRepairBay() {
    if (!player) return nullptr;
    for (auto& st : structures) {
        if (st->structType == StructureType::RepairBay &&
            st->team == Team::Red && !st->destroyed) {
            float dx = st->position.x - player->position.x;
            float dy = st->position.y - player->position.y;
            if (std::sqrt(dx*dx+dy*dy) < 150.f) return st.get();
        }
    }
    return nullptr;
}

void Game::handleUpgradeInput(sf::Keyboard::Key key) {
    if (!player) return;
    const UpgradeType upgrades[] = {
        UpgradeType::WeaponDamage, UpgradeType::WeaponFireRate,
        UpgradeType::ShieldCapacity, UpgradeType::ShieldRegen,
        UpgradeType::Speed, UpgradeType::HullArmor
    };

    if (key >= sf::Keyboard::Num1 && key <= sf::Keyboard::Num6)
        hud.upgradeMenuSelection = key - sf::Keyboard::Num1;
    if (key == sf::Keyboard::Up   && hud.upgradeMenuSelection > 0) hud.upgradeMenuSelection--;
    if (key == sf::Keyboard::Down && hud.upgradeMenuSelection < 5) hud.upgradeMenuSelection++;

    if (key == sf::Keyboard::Return || key == sf::Keyboard::Space) {
        if (economy.spend(Team::Red, UPGRADE_COST)) {
            player->applyUpgrade(upgrades[hud.upgradeMenuSelection]);
            hud.showNotification("Upgrade applied: " + upgradeName(upgrades[hud.upgradeMenuSelection]));
            hud.showUpgradeMenu = false;
        } else {
            hud.showNotification("Not enough credits! Need " + std::to_string(UPGRADE_COST));
        }
    }

    // Also repair hull
    if (key == sf::Keyboard::R) {
        int healCost = 50;
        if (economy.spend(Team::Red, healCost)) {
            player->hp = std::min(player->maxHp, player->hp + player->maxHp * 0.5f);
            player->shield = player->maxShield;
            hud.showNotification("Hull repaired! +50% HP");
        }
    }
}

// ─── RENDERING ─────────────────────────────────────────────────────────────

void Game::drawCenteredText(sf::RenderTarget& t, const std::string& str,
                             float y, int size, sf::Color col)
{
    if (!menuFontLoaded) return;
    sf::Text text;
    text.setFont(menuFont);
    text.setString(str);
    text.setCharacterSize(size);
    text.setFillColor(col);
    sf::FloatRect bounds = text.getLocalBounds();
    text.setPosition(WINDOW_W/2.f - bounds.width/2.f, y);
    t.draw(text);
}

void Game::render() {
    window.clear(sf::Color(4, 5, 12));

    switch(state) {
        case GameState::Menu:    renderMenu();     break;
        case GameState::Playing: renderGame();     break;
        case GameState::Paused:  renderGame(); renderPause(); break;
        case GameState::Victory: renderGame(); renderVictory(true);  break;
        case GameState::Defeat:  renderGame(); renderVictory(false); break;
    }

    window.display();
}

void Game::renderMenu() {
    // Starfield background
    sf::View menuView(sf::FloatRect(0,0,WINDOW_W,WINDOW_H));
    window.setView(menuView);

    // Draw some stars
    for (int i = 0; i < 200; i++) {
        srand(i * 137);
        float x = (float)(rand() % WINDOW_W);
        float y = (float)(rand() % WINDOW_H);
        float s = 0.5f + (rand()%20)*0.1f;
        sf::CircleShape dot(s);
        dot.setFillColor(sf::Color(200+rand()%55, 200+rand()%55, 220+rand()%35, 120+rand()%100));
        dot.setOrigin(s,s);
        dot.setPosition(x,y);
        window.draw(dot);
    }
    srand((unsigned)time(nullptr));

    drawCenteredText(window, "AIRSHIP BATTLE", 80, 52, sf::Color(220,180,60));
    drawCenteredText(window, "SPACE CONQUEST", 140, 24, sf::Color(120,160,220));

    // Ship selector
    const char* names[] = {"SCOUT","GUNSHIP","DREADNOUGHT","CARRIER","MINER"};
    const char* descs[] = {
        "Fast & agile | Low HP | Long vision range",
        "Balanced | Medium HP | Good DPS",
        "Heavy armor | High HP | Siege weapon",
        "Launches drones | Support role | Medium HP",
        "Resource collector | Earns bonus credits"
    };
    sf::Color shipCols[] = {
        sf::Color(160,240,160), sf::Color(220,220,100),
        sf::Color(240,160,80), sf::Color(200,140,240), sf::Color(140,200,240)
    };

    drawCenteredText(window, "Choose your ship:", 220, 18, sf::Color(180,180,180));
    drawCenteredText(window, "< / > Arrow Keys to browse", 248, 13, sf::Color(120,120,120));

    // Ship cards
    float cardW = 170.f, cardH = 120.f;
    float startX = WINDOW_W/2.f - 2.5f*cardW;
    for (int i = 0; i < 5; i++) {
        float cx = startX + i * (cardW + 8);
        bool sel = (i == selectedShipType);

        sf::RectangleShape card({cardW, cardH});
        card.setFillColor(sel ? sf::Color(30,50,80,220) : sf::Color(14,18,30,180));
        card.setOutlineColor(sel ? sf::Color(100,180,255) : sf::Color(40,55,80));
        card.setOutlineThickness(sel ? 2.5f : 1.f);
        card.setPosition(cx, 280);
        window.draw(card);

        // Ship silhouette
        float px = cx + cardW/2.f, py = 280 + 45.f;
        sf::ConvexShape ship; ship.setPointCount(5);
        float sz = 18.f;
        ship.setPoint(0, {0, -sz});
        ship.setPoint(1, {sz*0.55f, sz*0.5f});
        ship.setPoint(2, {sz*0.25f, sz*0.25f});
        ship.setPoint(3, {-sz*0.25f, sz*0.25f});
        ship.setPoint(4, {-sz*0.55f, sz*0.5f});
        ship.setFillColor(shipCols[i]);
        ship.setOutlineColor(sf::Color(220,80,80));
        ship.setOutlineThickness(1.5f);
        ship.setPosition(px, py);
        window.draw(ship);

        if (menuFontLoaded) {
            sf::Text t2;
            t2.setFont(menuFont);
            t2.setString(names[i]);
            t2.setCharacterSize(sel ? 15 : 13);
            t2.setFillColor(sel ? sf::Color(255,240,160) : sf::Color(180,180,180));
            sf::FloatRect b = t2.getLocalBounds();
            t2.setPosition(cx + cardW/2.f - b.width/2.f, 280 + 72.f);
            window.draw(t2);
        }
    }

    // Selected ship description
    drawCenteredText(window, descs[selectedShipType], 420, 14, sf::Color(160,200,200));

    drawCenteredText(window, "ENTER / SPACE  -  Launch Mission", 470, 18, sf::Color(120,220,120));
    drawCenteredText(window, "WASD: Move   Space: Fire   U: Upgrade   ESC: Pause", 510, 13, sf::Color(100,100,100));
    drawCenteredText(window, "Goal: Destroy the enemy NEXUS", 540, 14, sf::Color(180,140,80));
}

void Game::renderGame() {
    window.setView(gameView);

    // World background gradient
    sf::RectangleShape bg({WORLD_W, WORLD_H});
    bg.setFillColor(sf::Color(4, 5, 14));
    bg.setPosition(0,0);
    window.draw(bg);

    // World border
    sf::RectangleShape border({WORLD_W, WORLD_H});
    border.setFillColor(sf::Color::Transparent);
    border.setOutlineColor(sf::Color(60,60,100,120));
    border.setOutlineThickness(8.f);
    border.setPosition(0,0);
    window.draw(border);

    // World (stars, zones)
    world.draw(window, gameView);

    // Particles (behind ships)
    particles.draw(window);

    // Structures
    for (auto& st : structures) {
        st->draw(window);
    }

    // Ships
    for (auto& s : ships) {
        if (s->alive) s->draw(window);
    }

    // Projectiles
    for (auto& p : projectiles) {
        if (p.alive) p.draw(window);
    }

    // Player indicator arrow (if off-screen)
    if (player && player->alive) {
        sf::Vector2f ppos = player->position;
        sf::Vector2f center = gameView.getCenter();
        float hw = WINDOW_W/2.f - 30.f, hh = WINDOW_H/2.f - 30.f;
        float dx = ppos.x - center.x, dy = ppos.y - center.y;
        if (std::abs(dx) > hw || std::abs(dy) > hh) {
            // Draw arrow at edge
            sf::CircleShape arr(8.f, 3);
            arr.setFillColor(sf::Color(255,200,60,200));
            float angle = std::atan2(dy,dx)*180.f/3.14159f;
            arr.setRotation(angle+90.f);
            float ex = std::max(-hw, std::min(hw, dx));
            float ey = std::max(-hh, std::min(hh, dy));
            float len = std::sqrt(ex*ex+ey*ey);
            if (len > 0) { ex=(ex/len)*std::min(len,hw); ey=(ey/len)*std::min(len,hh); }
            arr.setOrigin(8.f,8.f);
            arr.setPosition(center.x+ex, center.y+ey);
            window.draw(arr);
        }
    }

    // Zone discovery labels (above zones that are discovered)
    if (menuFontLoaded) {
        for (auto& z : world.zones) {
            if (!z.discovered) continue;
            sf::Text zt;
            zt.setFont(menuFont);
            zt.setString(z.name);
            zt.setCharacterSize(11);
            zt.setFillColor(sf::Color(220,200,100,180));
            sf::FloatRect b = zt.getLocalBounds();
            zt.setPosition(z.position.x - b.width/2.f, z.position.y - z.radius - 18.f);
            window.draw(zt);
        }
    }

    // HUD
    ExplorationZone* zone = player ? world.getZoneAt(player->position) : nullptr;
    hud.draw(window, player, economy, fps, structures, zone, gameTime);
}

void Game::renderPause() {
    sf::View hv(sf::FloatRect(0,0,WINDOW_W,WINDOW_H));
    window.setView(hv);

    sf::RectangleShape overlay({(float)WINDOW_W,(float)WINDOW_H});
    overlay.setFillColor(sf::Color(0,0,0,140));
    window.draw(overlay);

    drawCenteredText(window, "PAUSED", WINDOW_H/2.f - 60, 48, sf::Color(220,180,60));
    drawCenteredText(window, "ESC / ENTER  -  Resume", WINDOW_H/2.f + 10, 20, sf::Color(180,220,180));
    drawCenteredText(window, "M  -  Main Menu", WINDOW_H/2.f + 44, 18, sf::Color(180,180,180));
}

void Game::renderVictory(bool win) {
    sf::View hv(sf::FloatRect(0,0,WINDOW_W,WINDOW_H));
    window.setView(hv);

    sf::RectangleShape overlay({(float)WINDOW_W,(float)WINDOW_H});
    overlay.setFillColor(sf::Color(0,0,0,160));
    window.draw(overlay);

    if (win) {
        drawCenteredText(window, "VICTORY!", WINDOW_H/2.f - 80, 64, sf::Color(220,200,60));
        drawCenteredText(window, "Enemy Nexus destroyed!", WINDOW_H/2.f, 24, sf::Color(160,220,160));
    } else {
        drawCenteredText(window, "DEFEAT", WINDOW_H/2.f - 80, 64, sf::Color(220,80,80));
        drawCenteredText(window, "Your Nexus has fallen.", WINDOW_H/2.f, 24, sf::Color(200,140,140));
    }

    std::ostringstream stats;
    stats << "Mission time: " << (int)gameTime/60 << "m " << (int)gameTime%60 << "s";
    drawCenteredText(window, stats.str(), WINDOW_H/2.f + 44, 16, sf::Color(180,180,180));
    drawCenteredText(window, "Credits earned: " + std::to_string(economy.redCredits),
                     WINDOW_H/2.f + 72, 16, sf::Color(180,200,100));

    drawCenteredText(window, "ENTER / SPACE  -  Main Menu", WINDOW_H/2.f + 120, 18, sf::Color(140,180,220));
}
